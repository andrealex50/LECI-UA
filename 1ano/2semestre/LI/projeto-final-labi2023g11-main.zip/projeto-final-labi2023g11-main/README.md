# labiproj
Repositório template para o projeto final de labi
O diretório report serve para armazenar os ficheiros do relatório latex
O diretório project serve para armazenar os ficheiros do servidor WEB
