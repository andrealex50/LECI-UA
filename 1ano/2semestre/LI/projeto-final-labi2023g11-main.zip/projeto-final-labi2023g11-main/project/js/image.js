var id;

$(document).ready(
    function(){
        const params = new URLSearchParams(window.location.search);
        id = params.get("id");
        imagecomments ();
        $.post("/checkforuser",
		{}, 
		function(response) {
			var responsejson = JSON.parse(response);
			if (responsejson.user == null){
				window.location.href = "/";
			}
		var text = "Logged in as: " + responsejson.user;
		$("#user").html(text);
	}); 
});      

function imagecomments() {
	$.get("/comments",
		{ idimg : id },
		function(response){
			showimageandinfo(response);
		});
}

function showimageandinfo(response) {
	// response.image is the image information
	// response.comments is the image list comments
	// response.votes is the image votes
	$("#imageinfo").html("");
	var image = new Image();
  
	image.onload = function() {
	  $(image).css({
		width: "550px",
		height: "450px"
	  });
	};
	
	image.src = "../" + response.image.path;
	
	var text = "<h4> Nome: " + response.image.name + "<br>Autor: " + response.image.author + "</h4>" + "<h5>Data: " + response.image.data + "</h5>" ;
	var container = $("<div>").html(text);
  
	container.append(image);
	$("#imageinfo").append(container);
	$("#comments").html("");
	for (let i = 0; i < response.comments.length; i++) {
	  var commenttext = "<h4>" + response.comments[i].user + ": " + response.comments[i].comment + "</h4>" + "<h5>"+response.comments[i].data + "</h5>";
	  var commentscontainer = $("<div>").html(commenttext);
  
	  $("#comments").append(commentscontainer);
	}
	$("#thumbs_up").html(response.votes.ups);
	$("#thumbs_down").html(response.votes.downs);

  }

  
function newcomment() {
	// obtain the user and comment from image page
	
	var comment = document.getElementById("comment").value;
	
	getuser()
		.then(function(response) {
			user = response;
			console.log(user);
			
			if (user == "" || comment == "") alert("Missing comment and/or username!");
			else {
		$.post("/newcomment",
			{ idimg: id, username: user, newcomment: comment },
			function() { imagecomments(); });
			}
		})
}



function upvote() {
	$.post("/upvote",
		{ idimg: id },
		function(response)
		{
			// update thumbs_up and thumbs_down
			var responsejson = JSON.parse(response);
			$("#thumbs_up").html(responsejson.ups);
		});
}

function downvote() {
	$.post("/removedownvote",
		{ idimg: id },
		function(response)
		{
			// update thumbs_up and thumbs_down	
			var responsejson = JSON.parse(response);
			$("#thumbs_down").html(responsejson.downs);
		});
}

function downvote() {
	$.post("/downvote",
		{ idimg: id },
		function(response)
		{
			// update thumbs_up and thumbs_down	
			var responsejson = JSON.parse(response);
			$("#thumbs_down").html(responsejson.downs);
		});
}

function removeupvote() {
	$.post("/removedownvote",
		{ idimg: id },
		function(response)
		{
			// update thumbs_up and thumbs_down	
			var responsejson = JSON.parse(response);
			$("#thumbs_down").html(responsejson.downs);
		});
}
function getuser() {
	return new Promise(function(resolve, reject) {
		$.post("/checkforuser", {}, function(response) {
			var responsejson = JSON.parse(response);
			user = responsejson.user;
			console.log(response);
			console.log(responsejson);
			resolve(user);
		}).fail(function(error) {
			reject(error);
		});
	});
}

function printuserlogin() {
	$.post("/checkforuser",
		{}, 
		function(response) {
			var responsejson = JSON.parse(response);
			console.log(response);
			console.log(responsejson);
			$("#user").html(responsejson.error);
			});
}
