$(document).ready(
	function(){
		imageslist("all");
});
 
$.post("/checkforuser",
{}, 
function(response) {
	var responsejson = JSON.parse(response);
	if (responsejson.user == null){
		window.location.href = "/";
	}
	var text = "Logged in as: " + responsejson.user;
	$("#user").html(text);
}); 

function imageslist(id) {
	var author;
	if (id == "all") author = "all";
	else {
			author = $("#authorImg").val();
			if (author == "") author = "all";
	}
	$.get("/list",
		{ id : author },
		function(response){
			showimages(response);
		});
}

function showimages(response) {
	// response.images is the list of dictionaries with the images information
	$("#showimages").html("");
	
	for (let i = 0; i < response.images.length; i++) {
		var image = new Image();

		image.onload = function() {
			$(image).css({
				width: "550px",
				height: "400px"
			});
		};
		image.src = "../" + response.images[i].path;

		var text = "<h2>" + response.images[i].name + "</h2><br>";
		var container = $("<div>").html(text);

		container.append(image);

		$("#showimages").append(container);
		$(container).on('click', function() {
			showimagecomments(response.images[i].id);
		});
	}
}


function showimagecomments(id) {
	window.open("../html/image.html?id=" + id, '_blank');
}

function getuser() {
	return new Promise(function(resolve, reject) {
		$.post("/checkforuser", {}, function(response) {
			var responsejson = JSON.parse(response);
			var author = responsejson.user;
			console.log(response);
			console.log(responsejson);
			resolve(author);
		}).fail(function(error) {
			reject(error);
		});
	});
}
