var file, img;

function updatePhoto(event) {
	var reader = new FileReader();
	reader.onload = function(event) {
		// Create an image
		img = new Image(); // Remove the 'var' keyword
		img.onload = function() {
			// Put image on screen
			const canvas = $("#photo")[0];
			const ctx = canvas.getContext("2d");
			ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, 550, 450);
		};
		img.src = event.target.result;
	};

	file = event.target.files[0];
	// Obtain the file
	reader.readAsDataURL(file);
}

function uploadImage() {
	if (file != null) {
		sendFile(file);
		// Release the resources allocated to the selected image
		window.URL.revokeObjectURL(file);
	} else {
		alert("Missing image!");
	}
}

function sendFile(file) {
	var data = new FormData();
	data.append("myFile", file);
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "/uploadTmp");
	xhr.upload.addEventListener("progress", updateProgress(this), false);
	xhr.send(data);
}

function updateProgress(evt) {
	if (evt.loaded == evt.total) {
		alert("Okay");
	}
}

function grayScale() {
	$.get(
		"/grayScale",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

function negative() {
	$.get(
		"/negative",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

function sepia() {
	$.get(
		"/sepia",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

function blur() {
	$.get(
		"/blur",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

function sharpen() {
	$.get(
		"/sharpen",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

function edgeDetection() {
	$.get(
		"/edgeDetection",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

function emboss() {
	$.get(
		"/emboss",
		{ image: img.src },
		function(response) {
			var newImage = new Image();
			newImage.onload = function() {
				const canvas = $("#photoprocessed")[0];
				const ctx = canvas.getContext("2d");
				ctx.drawImage(newImage, 0, 0, newImage.width, newImage.height, 0, 0, 550, 450);
			};
			newImage.src = response;
		}
	);
}

$.post("/checkforuser",
	{}, 
	function(response) {
		var responsejson = JSON.parse(response);
		var text = "Logged in as: " + responsejson.user;
		$("#user").html(text);
		}); 



