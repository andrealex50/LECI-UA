import pytest
import requests
import os

BASE_URL = "http://localhost:8080"
TMP_DIR = "tmp"
UPLOADS_DIR = "uploads"

# Function to empty a directory
def empty_directory(directory):
    for file_name in os.listdir(directory):
        file_path = os.path.join(directory, file_name)
        if os.path.isfile(file_path):
            os.remove(file_path)
        elif os.path.isdir(file_path):
            os.rmdir(file_path)

# Empty the 'tmp' and 'uploads' directories before running the tests
empty_directory(TMP_DIR)
empty_directory(UPLOADS_DIR)

# Test the upload method
def test_upload():
    url = BASE_URL + "/upload"
    files = {"myFile": open("test_image.jpg", "rb")}
    data = {"nameImg": "Test Image", "authorImg": "Test Author"}
    response = requests.post(url, files=files, data=data)
    assert response.status_code == 200
    assert response.text == "Image uploaded successfully"

# Test the list method
def test_list():
    url = BASE_URL + "/list/all"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert "images" in data

# Test the comments method
def test_comments():
    url = BASE_URL + "/comments/1"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert "image" in data
    assert "comments" in data

# Test the newcomment method
def test_newcomment():
    url = BASE_URL + "/newcomment/1"
    data = {"username": "Test User", "newcomment": "Test Comment"}
    response = requests.post(url, data=data)
    assert response.status_code == 200

# Test the downvote method
def test_downvote():
    url = BASE_URL + "/downvote/1"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert "downs" in data

# Test the upvote method
def test_upvote():
    url = BASE_URL + "/upvote/1"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert "ups" in data

# Test the uploadTmp method
def test_uploadTmp():
    url = BASE_URL + "/uploadTmp"
    files = {"myFile": open("test_image.jpg", "rb")}
    response = requests.post(url, files=files)
    assert response.status_code == 200
    assert response.text == "Image uploaded"

    # Remove files from 'tmp' directory after the test
    empty_directory(TMP_DIR)

# Test the processing methods
def test_processing_methods():
    image_url = BASE_URL + "/uploadTmp"
    files = {"myFile": open("test_image.jpg", "rb")}
    response = requests.post(image_url, files=files)
    assert response.status_code == 200

    processing_methods = ["sharpen", "grayScale", "negative", "sepia", "blur", "edgeDetection", "emboss"]
    for method in processing_methods:
        # Empty the 'tmp' directory before each processing method
        empty_directory(TMP_DIR)

        url = BASE_URL + f"/{method}"
        response = requests.get(url, params={"image": "processimage.jpg"})
        assert response.status_code == 200
        # Add assertions to validate the processed image or response data

# Run the tests
if __name__ == "__main__":
    pytest.main()
