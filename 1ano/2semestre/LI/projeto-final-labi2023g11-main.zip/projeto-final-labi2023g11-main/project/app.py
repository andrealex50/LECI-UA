# encoding=utf-8

# To run: python3 app.py

import os.path
import cherrypy
import json
import hashlib
import sqlite3 as sql
import time
import requests
import process
from PIL import Image


# The absolute path to this file's base directory
baseDir = os.path.abspath(os.path.dirname(__file__))

# Dictionary with this application's static directories configuration
config = {
			"/":		{	"tools.staticdir.root": baseDir, 'tools.sessions.on': True},
			"/html":	{	"tools.staticdir.on": True, "tools.staticdir.dir": "html" },
			"/js":		{	"tools.staticdir.on": True, "tools.staticdir.dir": "js" },
			"/css":		{	"tools.staticdir.on": True, "tools.staticdir.dir": "css" },
			"/images":	{	"tools.staticdir.on": True, "tools.staticdir.dir": "images" },
			"/uploads":	{	"tools.staticdir.on": True, "tools.staticdir.dir": "uploads" }, 
			"/tmp":    {   "tools.staticdir.on": True, "tools.staticdir.dir": "uploads" },      
}


class Root(object):
	
	#main page
	@cherrypy.expose
	def main(self):
		cherrypy.response.headers["Content-Type"] = "text/html"
		data = {"username": cherrypy.session.get('user')}
		response = requests.post("http://localhost:8080/main", data=data)
		return response.text

	
	#log in page
	@cherrypy.expose
	def index(self):
		if (cherrypy.session.get('user') != None):
			username = cherrypy.session.get('user')
			db = sql.connect('database.db')
			cursor = db.cursor()
			result = cursor.execute("SELECT password FROM users WHERE user = (?)", (username,) )		
			for storedpasswords in result:
				cpassword = storedpasswords[0]
			return Actions.doLogin(self, username= cherrypy.session.get('user'), password=cpassword)
		cherrypy.response.headers["Content-Type"] = "text/html"
		return open("html/index.html")
		
	#sign up page
	@cherrypy.expose
	def signup(self):
		if (cherrypy.session.get('user') != None):
			username = cherrypy.session.get('user')
			db = sql.connect('database.db')
			cursor = db.cursor()
			result = cursor.execute("SELECT password FROM users WHERE user = (?)", (username,) )		
			for storedpasswords in result:
				cpassword = storedpasswords[0]
			return Actions.doLogin(self, username= cherrypy.session.get('user'), password=cpassword)
		cherrypy.response.headers["Content-Type"] = "text/html"
		return open("html/signin.html")
	
	#check if theres an error
	@cherrypy.expose
	def checkforerror(self):
		return json.dumps({"error": cherrypy.session.get("error")}).encode("utf-8")
	
	#check if theres logged in person
	@cherrypy.expose
	def checkforuser(self):
		return json.dumps({"user": cherrypy.session.get("user")}).encode("utf-8")
	
	#do logout
	@cherrypy.expose
	def logout(self):
		cherrypy.session.clear()
		raise cherrypy.HTTPRedirect('/actions/doLogin')
	
	@cherrypy.expose
	def login(self, username):
		db = sql.connect('database.db')
		cursor = db.cursor()
		result = cursor.execute("SELECT password FROM users WHERE user = (?)", (username,) )		
		for storedpasswords in result:
			password = storedpasswords[0]
		data = {"username": cherrypy.session.get('user'), "password": password}
		requests.post("http://localhost:8080", data)
		
	def __init__(self):
		self.actions = Actions()
		
		
	# UpLoad image
	@cherrypy.expose
	def upload(self, myFile, nameImg, authorImg):
		h = hashlib.sha256()

		filename = baseDir + "/uploads/" + myFile.filename
		fileout = open(filename, "wb")
		while True:
			data = myFile.file.read(8192)
			if not data: break
			fileout.write(data)
			h.update(data)
		fileout.close()
		
		ext = myFile.filename.split(".")[-1]
		# final path of the image and changing the filename
		path = "uploads/" + h.hexdigest() + "." + ext
		os.rename(filename, path)

		
		# obtain the date and time of loading
		datetime = time.strftime('date:%d-%m-%Y time:%H:%M:%S')

		# insert the file information in the images table
		db = sql.connect('database.db')
		query = "INSERT INTO images(nameImg, authorImg, path, datetime) VALUES (?, ?, ?, ?)"
		cursor = db.cursor()
		cursor.execute(query, (nameImg, authorImg, path, datetime))
		db.commit()

		db.close()
		return "Image uploaded successfully"
	
	# List requested images
	@cherrypy.expose
	def list(self, id):
		db = sql.connect('database.db')
		if (id == "all"):
			query = "SELECT * FROM images"
			result = db.execute(query)
		else:
			query = "SELECT * FROM images WHERE author = ?"
			result = db.execute(query, (id,))
		rows = result.fetchall()
		db.close()

		# Generate result (list of dictionaries) from rows (list of tuples)
		result = []

		for row in rows:
			image = {}
			image["id"] = row[0]
			image["name"] = row[1]
			image["author"] = row[2]
			image["path"] = row[3]
			image["data"] = row[4]
			result.append(image)

		# Sort result by image name before return
		result.sort(key=lambda x: x['name'])

		cherrypy.response.headers["Content-Type"] = "application/json"
		return json.dumps({"images": result}).encode("utf-8")
		
	# List comments
	
	@cherrypy.expose
	def comments(self, idimg):
		db = sql.connect('database.db')
		result_images = db.execute("SELECT * FROM images WHERE id = ?", (idimg,))
		row_images = result_images.fetchone()

		# Generate output dictionary with image information
		imageinfo = dict()
		imageinfo["id"] = row_images[0]
		imageinfo["name"] = row_images[1]
		imageinfo["author"] = row_images[2]
		imageinfo["path"] = row_images[3]
		imageinfo["data"] = row_images[4]

		result_comments = db.execute("SELECT * FROM comments WHERE idimg = ?", (idimg,))
		rows_comments = result_comments.fetchall()

		# Generate output dictionary with image comments list
		comments = []
		for com in rows_comments:
			comment = {}
			comment["id"] = com[0]
			comment["idimg"] = com[1]
			comment["user"] = com[2]
			comment["comment"] = com[3]
			imageinfo["data"] = com[4]
			comments.append(comment)

		result_votes = db.execute("SELECT * FROM votes WHERE idimg = ?", (idimg,))
		row_votes = result_votes.fetchone()

		# Generate output dictionary with image votes
		imagevotes = dict()
		if row_votes is not None:
			imagevotes["ups"] = row_votes[2]
			imagevotes["downs"] = row_votes[3]
			imagevotes["idimg"] = row_votes[1]  
			imagevotes["id"] = row_votes[0]
		else:
			imagevotes["idimg"] = idimg
			query = "INSERT INTO votes(idimg, ups, downs) VALUES (?, ?, ?)"
			cursor = db.cursor()
			cursor.execute(query, (idimg, 0, 0))
			db.commit()


		db.close()

		cherrypy.response.headers["Content-Type"] = "application/json"
		return json.dumps({"image": imageinfo, "comments": comments, "votes": imagevotes}).encode("utf-8")
	
	# UpLoad comment
	@cherrypy.expose
	def newcomment(self, idimg, username, newcomment):
		datetime = time.strftime('date:%d-%m-%Y time:%H:%M:%S')
		db = sql.connect('database.db')
		query = "INSERT INTO comments(idimg, user, comment, datetime) VALUES (?, ?, ?, ?)"
		cursor = db.cursor()
		cursor.execute(query, (idimg, username, newcomment, datetime))
		db.commit()
		db.close()

	# Decrement Down votes
	@cherrypy.expose
	def removedownvote(self, idimg):
		db = sql.connect('database.db')
		cursor = db.cursor()
		cursor.execute('SELECT downs FROM votes WHERE idimg = ?', (idimg,))
		existing_record = cursor.fetchone()

		current_downs = existing_record[0]
		new_downs = current_downs - 1
		cursor.execute('UPDATE votes SET downs = ? WHERE idimg = ?', (new_downs, idimg))
		db.commit()

		cursor.execute('SELECT downs FROM votes WHERE idimg = ?', (idimg,))
		updated_votes = cursor.fetchone()
		db.close()
		return json.dumps({"downs": updated_votes[0]}).encode("utf-8")
		
	# Increment Down votes
	@cherrypy.expose
	def downvote(self, idimg):
		db = sql.connect('database.db')
		cursor = db.cursor()
		cursor.execute('SELECT downs FROM votes WHERE idimg = ?', (idimg,))
		existing_record = cursor.fetchone()

		current_downs = existing_record[0]
		new_downs = current_downs + 1
		cursor.execute('UPDATE votes SET downs = ? WHERE idimg = ?', (new_downs, idimg))
		db.commit()

		cursor.execute('SELECT downs FROM votes WHERE idimg = ?', (idimg,))
		updated_votes = cursor.fetchone()
		db.close()
		return json.dumps({"downs": updated_votes[0]}).encode("utf-8")

	# Decrement Up votes
	@cherrypy.expose
	def upvote(self, idimg):
		db = sql.connect('database.db')
		cursor = db.cursor()
		cursor.execute('SELECT ups FROM votes WHERE idimg = ?', (idimg,))
		existing_record = cursor.fetchone()

		current_ups = existing_record[0]
		new_ups = current_ups - 1
		cursor.execute('UPDATE votes SET ups = ? WHERE idimg = ?', (new_ups, idimg))
		db.commit()

		cursor.execute('SELECT ups FROM votes WHERE idimg = ?', (idimg,))
		updated_votes = cursor.fetchone()
		db.close()
		return json.dumps({"ups": updated_votes[0]}).encode("utf-8")

	# Increment Up votes
	@cherrypy.expose
	def upvote(self, idimg):
		db = sql.connect('database.db')
		cursor = db.cursor()
		cursor.execute('SELECT ups FROM votes WHERE idimg = ?', (idimg,))
		
		existing_record = cursor.fetchone()
		current_ups = existing_record[0]
		new_ups = current_ups + 1
		cursor.execute('UPDATE votes SET ups = ? WHERE idimg = ?', (new_ups, idimg))
		db.commit()

		cursor.execute('SELECT ups FROM votes WHERE idimg = ?', (idimg,))
		updated_votes = cursor.fetchone()
		db.close()
		return json.dumps({"ups": updated_votes[0]}).encode("utf-8")
	#Process
	@cherrypy.expose
	def sharpen(self, image):		#função para a o algoritmo sharpen
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		return process.sharpen(image)

	
	@cherrypy.expose
	def grayScale(self, image):		#função para a o algoritmo grayScale
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		return process.grayScale(image)

	@cherrypy.expose				
	def negative(self, image):			#função para a o algoritmo negative
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		return process.negative(image)	

	@cherrypy.expose
	def sepia(self, image):			#função para a o algoritmo sepia
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		return process.sepia(image)
	
	@cherrypy.expose
	def blur(self, image):			#função para a o algoritmo blur
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		return process.blur(image)	
	
	@cherrypy.expose
	def edgeDetection(self, image):		#função para a o algoritmo edgeDetection
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		return process.edgeDetection(image)	
	
	@cherrypy.expose
	def emboss(self, image):  # função para o algoritmo emboss
		tmpDir = os.path.join(baseDir, "tmp")  # diretório temporário
		image_files = os.listdir(tmpDir)  # lista de arquivos no diretório temporário
		image_path = os.path.join(tmpDir, image_files[0])  # caminho da primeira imagem no diretório temporário
		image = Image.open(image_path)  # abre a imagem
		result = process.emboss(image)  # aplica a função do process.py na imagem
		return result  
		
class Actions(object):
	
	@cherrypy.expose
	def doLogin(self, username=None, password=None):
		
		#check log in with database
		db = sql.connect('database.db')
		cursor = db.cursor()
		result = cursor.execute("SELECT password FROM users WHERE user = (?)", (username,) )		
		for storedpasswords in result:
			if password == storedpasswords[0]:
				cherrypy.session["user"] = username
				cherrypy.session["error"] = None
				return open("html/main.html")
		cherrypy.session["error"] = "Invalid login"
		if (username=='' and password=='') or (username==None and password==None): cherrypy.session["error"]=None
		raise cherrypy.HTTPRedirect('/')
		
		
	
	@cherrypy.expose
	def doSignin(self, username=None, password=None, cpassword=None):
		
		#pop up error if both passwords aren't the same
		if (password != cpassword) or (len(password) < 8) or len(username) < 4:
			cherrypy.session["error"] = "Invalid password or user"
			raise cherrypy.HTTPRedirect('/')
		
		db = sql.connect('database.db')
		result = db.execute("SELECT user FROM users")
		
		for data in result:
			if username == data[0]:
				db.commit()
				db.close()
				cherrypy.session["error"] = "Username already chosen"
				raise cherrypy.HTTPRedirect('/')
		
		db.execute("INSERT INTO users(user, password) VALUES (?,?)", (username, password) )
		db.commit()
		db.close()		
		#change this session name to its user name
		cherrypy.session["error"] = None
		cherrypy.session["user"] = username
		return open("html/main.html")

		
		
cherrypy.quickstart(Root(), "/", config)
