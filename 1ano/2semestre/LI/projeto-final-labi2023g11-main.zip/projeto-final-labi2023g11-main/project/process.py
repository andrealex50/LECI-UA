from PIL import Image

def grayScale(image):
    return image.convert("L")

def negative(image):
    return Image.eval(image, lambda pixel: 255 - pixel)

def sepia(image):
    width, height = image.size
    sepia_image = Image.new("RGB", (width, height))
    pixels = sepia_image.load()
    for i in range(width):
        for j in range(height):
            r, g, b = image.getpixel((i, j))
            sepia_r = int((r * 0.393) + (g * 0.769) + (b * 0.189))
            sepia_g = int((r * 0.349) + (g * 0.686) + (b * 0.168))
            sepia_b = int((r * 0.272) + (g * 0.534) + (b * 0.131))
            pixels[i, j] = (min(sepia_r, 255), min(sepia_g, 255), min(sepia_b, 255))
    
    return sepia_image

def blur (image):
    width, height = image.size
    blur_image = Image.new("RGB", (width, height))
    pixels = blur_image.load()
    for i in range(width):
        for j in range(height):
            r, g, b = image.getpixel((i, j))
            blur_r = int((r * 0.393) + (g * 0.769) + (b * 0.189))
            blur_g = int((r * 0.349) + (g * 0.686) + (b * 0.168))
            blur_b = int((r * 0.272) + (g * 0.534) + (b * 0.131))
            pixels[i, j] = (min(blur_r, 255), min(blur_g, 255), min(blur_b, 255))
    
    return blur_image

def sharpen (image):
    width, height = image.size
    sharpen_image = Image.new("RGB", (width, height))
    pixels = sharpen_image.load()
    for i in range(width):
        for j in range(height):
            r, g, b = image.getpixel((i, j))
            sharpen_r = int((r * 0.393) + (g * 0.769) + (b * 0.189))
            sharpen_g = int((r * 0.349) + (g * 0.686) + (b * 0.168))
            sharpen_b = int((r * 0.272) + (g * 0.534) + (b * 0.131))
            pixels[i, j] = (min(sharpen_r, 255), min(sharpen_g, 255), min(sharpen_b, 255))
    
    return sharpen_image

def edgeDetection (image):
    width, height = image.size
    edgeDetection_image = Image.new("RGB", (width, height))
    pixels = edgeDetection_image.load()
    for i in range(width):
        for j in range(height):
            r, g, b = image.getpixel((i, j))
            edgeDetection_r = int((r * 0.393) + (g * 0.769) + (b * 0.189))
            edgeDetection_g = int((r * 0.349) + (g * 0.686) + (b * 0.168))
            edgeDetection_b = int((r * 0.272) + (g * 0.534) + (b * 0.131))
            pixels[i, j] = (min(edgeDetection_r, 255), min(edgeDetection_g, 255), min(edgeDetection_b, 255))
    
    return edgeDetection_image

def emboss (image):
    width, height = image.size
    emboss_image = Image.new("RGB", (width, height))
    pixels = emboss_image.load()
    for i in range(width):
        for j in range(height):
            r, g, b = image.getpixel((i, j))
            emboss_r = int((r * 0.393) + (g * 0.769) + (b * 0.189))
            emboss_g = int((r * 0.349) + (g * 0.686) + (b * 0.168))
            emboss_b = int((r * 0.272) + (g * 0.534) + (b * 0.131))
            pixels[i, j] = (min(emboss_r, 255), min(emboss_g, 255), min(emboss_b, 255))
    
    return emboss_image