# labiaprof
Código para o trabalho de aprofundamento de labi

Trabalho realizado por:
André Afonso Melo Alexandre;  Nº114143;   email: alexandreandre@ua.pt;    Contribuição: 54%
Tiago José Costa Melo;  Nº113362;    email: tiagojcm04@ua.pt;    Contribuição: 46%
