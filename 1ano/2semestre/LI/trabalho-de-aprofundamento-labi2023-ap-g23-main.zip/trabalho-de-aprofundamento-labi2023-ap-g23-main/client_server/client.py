#!/usr/bin/python3
# coding: utf-8

import os
import sys
import socket
import base64
import hashlib
from common_comm import send_dict, recv_dict, sendrecv_dict

from Cryptodome.Cipher import AES
from Cryptodome.Hash import SHA256

# Function to encript values for sending in json format
# return int data encrypted in a 16 bytes binary string coded in base64
def encrypt_intvalue(cipherkey, data):
    cipher = AES.new(cipherkey, AES.MODE_ECB)    #criação de um novo objeto AES usando a chave cipherkey
    encrypted_data = cipher.encrypt(bytes('%16d' % data, 'utf-8'))    #o número inteiro é convertido numa string binária com 128 bits
    data_tosend = base64.b64encode(encrypted_data).decode("utf-8")    #codifica uma string binária para texto usando a função base64.b64encode 
    return data_tosend


# Function to decript values received in json format
# return int data decrypted from a 16 bytes binary strings coded in base64
def decrypt_intvalue (cipherkey, data):
    data_decoded = base64.b64decode(str(data))    #descodifica uma string binária para texto usando a função base64.b64decode 
    cipher = AES.new(cipherkey, AES.MODE_ECB)    #criação de um novo objeto AES usando a chave cipherkey
    decrypted_data = cipher.decrypt(data_decoded)    #decripta a data através da função decrypt
    decrypted_data_decoded = int(decrypted_data.decode("utf-8"))    #descodifica a data usando a codificação UTF-8, para criar um string, depois convertida para int
    return decrypted_data_decoded


# verify if response from server is valid or is an error message and act accordingly - já está implementada
def validate_response (client_sock, response):
	if not response["status"]:
		print (response["error"])
		client_sock.close ()
		sys.exit (3)


# process QUIT operation
def quit_action (client_sock, attempts):
    send_dict(client_sock, {"op": "QUIT"})      #envia dicionário da operação QUIT para o server
    response = recv_dict(client_sock)    #recebe a resposta do server
    validate_response(client_sock, response)    #valida a resposta do server
    client_sock.close()    #fecha a conexão
    print("Number of attempts: " + str(attempts))
    sys.exit(0)


# Outcomming message structure:
# { op = "START", client_id, [cipher] }
# { op = "QUIT" }
# { op = "NUMBER", number }
# { op = "STOP", [shasum] }
# { op = "GUESS", choice }
#
# Incomming message structure:
# { op = "START", status }
# { op = "QUIT" , status }
# { op = "NUMBER", status }
# { op = "STOP", status, value }
# { op = "GUESS", status, result }

#
# Suport for executing the client pretended behaviour
#

def run_client(client_sock, client_id):
    listnumbers = []    #lista para armazenar os números
    attempts = 0
    while True:
        choice = input("Enter the choice: ")

        if choice.upper() == "START":
            while True:
                wantcipher = input("Interact with the server in encrypted mode? y/n: ")    #permite a escolha entre dados criptografados ou não
                if wantcipher.lower() == "y":
                    cipherkey = os.urandom(16)    # chave de cifra binária aleatória de 16 bytes
                    cipherkeyencoded = str(base64.b64encode(cipherkey), "utf8")    #codificação da chave em base24
                    break
                elif wantcipher.lower() == "n":
                    cipherkeyencoded = None    #caso o utilizador opte por não usar dados criptografados
                    break
                else:
                    print("Invalid choice! Please enter Y or n.")
                    
            send_dict(client_sock, {"op": "START", "client_id": client_id, "cipher": cipherkeyencoded})     #envia dicionário ao server
            response = recv_dict(client_sock)    #recebe dicionário do server
            validate_response(client_sock, response)    #valida a resposta do server

        elif choice.upper() == "QUIT":
            listnumbers = []    #limpa a lista de números
            quit_action (client_sock, attempts)

        elif choice.upper() == "NUMBER":
            numberinput = input("Number: ")
            while not numberinput.isdigit():
                print("Invalid number! Must be an integer")    #só aceita valores inteiros
                numberinput = input("Number: ")
            number = int(numberinput)    #converte para inteiros depois
            try:                
                numberencrypted = encrypt_intvalue(cipherkey, number)    #encripta o número introduzido
            except UnboundLocalError:     #caso não exista cipherkey, vai ocorrer o erro UnBoundLocalError, que é tratado como única exceção
                numberencrypted = number
            
            listnumbers.append(number)    #guarda o número na lista em formato int                           
            send_dict(client_sock, {"op": "NUMBER", "number": numberencrypted})    #o número encriptado é guardado no dicionário que é enviado para o server
            response = recv_dict(client_sock)    #recebe o dicionário do server
            validate_response(client_sock, response)    #valida a resposta do server

        elif choice.upper() == "STOP":
            keysha = hashlib.sha256()    #cria um objeto de hash SHA-256
            keysha.update(str(listnumbers).encode())    #converte a lista de números em uma string e codifica
            hash = keysha.digest()   #obtem o valor do hash
            hash_encoded = base64.b64encode(hash)        # o valor da síntese é guardado nos dicionários usando o formato Base64.
            send_dict(client_sock, {"op": "STOP", "shasum": hash_encoded.decode('utf-8')})   #descodifica o hash e envia para o server
            response = recv_dict(client_sock)   #recebe a resposta do server
            validate_response(client_sock, response)    #valida a resposta do server
            print("numbers sent to server: " + str(listnumbers))    #imprime os números enviados ao server
            try:
                print("Number chosen by the server: " + str(decrypt_intvalue(cipherkey, response["value"])))    #imprime o número escolhido pelo server
            except UnboundLocalError:
                print("Number chosen by the server: " + str(response["value"]))

        elif choice.upper() == "GUESS":
            escolha = input("Guess the characteristic: ")
            while escolha not in ["min", "max", "first", "last", "median"]:    #se o input for inválido imprime mensagem e só prossegue quando for válido
                print("Invalid characteristic!")
                escolha = input("Guess the characteristic: ")
            attempts += 1
            send_dict(client_sock, {"op": "GUESS", "choice": escolha})   #envia o dicionário para o server 
            response = recv_dict(client_sock)    #recebe a resposta do server
            validate_response(client_sock, response)     #valida a resposta do server
            print("You guess it!")
            listnumbers = []

        else:
            print("Invalid Operation!")



def main():
    # validate the number of arguments and eventually print error message and exit with error
    # verify type of of arguments and eventually print error message and exit with error

    if len(sys.argv) not in [3,4]:    #se o número de argumentos dados for inválido
        print("Número de argumentos inválido")
        exit()

    try:
        port = int(sys.argv[2])
        if port < 0:     #se o port for negativo
            raise ValueError
    except ValueError:    #se o port não for um número inteiro
        print("O valor do porto não é um valor inteiro positivo!")
        exit()       

    try:
        if len(sys.argv) == 4:
            hostname = sys.argv[3]
            str_arg3 = hostname.split(".")
            if len(str_arg3) != 4:     #se o comprimento do  hostname for diferente de 4
                raise ValueError
            else:
                for x in str_arg3:
                    if(not x.isdigit() or int(x)>255 or int(x)<0):    #se cada valor do hostname for maior que 255 or menor que 0 ou não inteiro
                        raise ValueError
        else:
            hostname = "127.0.0.1"    #se não for dado um endereço usar este como default

    except ValueError:
        print("O endereço IPv4 não é válido")
        exit()

    # obtain the port number
    # port = ?   FEITO

    # obtain the hostname that can be the localhost or another host
    # hostname = ?   FEITO

    client_socket = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
    client_socket.bind(("0.0.0.0", 0))
    client_socket.connect ((hostname, port))

    run_client (client_socket, sys.argv[1])

    client_socket.close ()
    sys.exit (0)

if __name__ == "__main__":
    main()