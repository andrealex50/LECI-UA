import pytest

from client import encrypt_intvalue, decrypt_intvalue
from subprocess import Popen
from subprocess import PIPE

#----Testes funcionais----

def test_numArgs ():
    proc = Popen ("python3 client.py", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "Número de argumentos inválido\n"

    proc = Popen("python3 client.py rui", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "Número de argumentos inválido\n"

    proc = Popen("python3 client.py sofia 3530 127.0.0.1 125", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "Número de argumentos inválido\n"

    print("*- CLIENT número de argumentos inválido: PASSOU")

def test_typeArgs() :
    proc = Popen ("python3 client.py rui -1", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "O valor do porto não é um valor inteiro positivo!\n"

    proc = Popen ("python3 client.py ana 1.3", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "O valor do porto não é um valor inteiro positivo!\n"

    print("*- CLIENT tipo de argumentos inválido: PASSOU")

#----Teste unitários----

def test_encrypt_intvalue():
    cipherkey = b'0123456789012345'
    data = 1234
    encrypted_data = encrypt_intvalue(cipherkey, data)
    assert encrypted_data != data

    print("*- CLIENT encriptação correta: PASSOU")

def test_decrypt_intvalue():
    cipherkey = b'AS23456789017345'
    data = 111
    encrypted_data = encrypt_intvalue(cipherkey, data)
    decrypted_data = decrypt_intvalue(cipherkey, encrypted_data)
    assert decrypted_data == data

    print("*- CLIENT decriptação correta: PASSOU")


