import pytest
import pytest

from server import encrypt_intvalue, decrypt_intvalue, new_client, users, clean_client, quit_client, number_client, stop_client, guess_client
from subprocess import Popen
from subprocess import PIPE
import hashlib
import base64

#----Testes Unitários----

def test_new_client():
    client_sock = "random_client_socket"
    request = {"client_id": "manel", "cipher": 'AS23456789017345'}

    #cliente novo
    client1 = new_client(client_sock, request)
    assert client1 == {"op": "START", "status": True}
    
    #testar caso já exista
    client1_also = new_client(client_sock, request)
    assert client1_also == {"op": "START", "status": False, "error": "Cliente já existe"}


'''
def test_clean_client():
    client_sock = "random_client_socket"
    users={}
    users["joaquim"] = {"socket": client_sock, "cipher": "AS23456789017323", "numbers": []}
    clean_client(client_sock)
    #elimina e vê se ainda está presente em users
    assert "joaquim" not in users
'''

'''
def test_quit_client():
    #se o utilizador estiver ativo
    client_sock = "random_client_socket"
    request = {"client_id": "manel", "cipher": 'AS23456789017345', "numbers": []}
    result = quit_client(client_sock, request)
    assert result == {"op": "QUIT", "status": True}

    #se o utilizador estiver inativo
    client_not_present = {"client_id": None, "cipher": 'AS23456789017345', "numbers": []}
    result1 = quit_client(client_sock, client_not_present)
    assert result1 == {"op": "QUIT", "status": False, "error": "Cliente inexistente"}
''' 

def test_number_client():
    client_sock = "random_client_socket"
    request = {"client_id": "manel", "cipher": None, "number": 123}

    users["manel"] = {"socket": client_sock, "cipher": None, "numbers": []}

    result = number_client(client_sock, request)
    assert result == {"op": "NUMBER", "status": True}
    assert users["manel"]["numbers"] == [123]



#----Testes funcionais----

def test_num_Args ():

    proc = Popen("python3 server.py", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "Número de argumentos inválido!"+"\n"

    proc = Popen("python3 server.py 8 3530", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "Número de argumentos inválido!"+"\n"

    print("*- SERVER número de argumentos inválido: PASSOU")

def test_type_Args ():

    proc = Popen("python3 server.py -1", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "O valor do porto não é um valor inteiro positivo!"+"\n"

    proc = Popen("python3 server.py 1.5", stdout=PIPE, shell=True)
    assert proc.wait() == 0
    assert proc.stdout.read().decode('utf-8') == "O valor do porto não é um valor inteiro positivo!"+"\n"

    print("*- SERVER tipo de argumentos inválido: PASSOU")