//
// Algoritmos e Estruturas de Dados --- 2023/2024
//
// Topological Sorting
//

#include "GraphTopologicalSorting.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "IntegersQueue.h"
#include "instrumentation.h"

struct _GraphTopoSort {
  int* marked;                     // Aux array
  unsigned int* numIncomingEdges;  // Aux array
  unsigned int* vertexSequence;    // The result
  int validResult;                 // 0 or 1
  unsigned int numVertices;        // From the graph
  Graph* graph;
};


#define COMP InstrCount[0]
#define ATRIB InstrCount[1]

// AUXILIARY FUNCTION
// Allocate memory for the struct
// And for its array fields
// Initialize all struct fields
//
static GraphTopoSort* _create(Graph* g) {
  assert(g != NULL);
  InstrName[0]= "ncomp";
  InstrName[1]= "atrib";
  GraphTopoSort* p = NULL;

  // TO BE COMPLETED
  p = (GraphTopoSort*)malloc(sizeof(GraphTopoSort));  // alocamos o espaço para a struct 
  if (p == NULL) {   // verificamos se a alocação foi bem sucedida
    free(p);    // se não libertamos o espaço da memória previamente reservado
    return NULL;  
  }

  p->graph = g;   // inicializamos a variavel graph na struct 
  p->numVertices = GraphGetNumVertices(g);   // inicializamos o número de vertices 
  p->validResult = 0;   // inicializamos o validResult com 0

  p->marked = (int*)malloc((p->numVertices) * sizeof(int));   // Alocamos o espaço do array marked
  p->numIncomingEdges = (unsigned int*)malloc((p->numVertices)* sizeof(unsigned int));  // do array numIncomingEdges
  p->vertexSequence = (unsigned int*)malloc((p->numVertices) * sizeof(unsigned int));   // do array vertexSequence
  // com a dimensão do numVertices porque cada espaço do array corresponde a um vertice

  // Se a alocação correr mal em algum, libertamos o espaço alocado anteriormente
  if (p->marked == NULL || p->numIncomingEdges == NULL || p->vertexSequence == NULL) {
    free(p->marked);    
    free(p->numIncomingEdges);
    free(p->vertexSequence);
    free(p);
    return NULL;
  }

  return p;
}

//
// Computing the topological sorting, if any, using the 1st algorithm:
// 1 - Create a copy of the graph
// 2 - Successively identify vertices without incoming edges and remove their
//     outgoing edges
// Check if a valid sorting was computed and set the isValid field
// For instance, by checking if the number of elements in the vertexSequence is
// the number of graph vertices
//


GraphTopoSort* GraphTopoSortComputeV1(Graph* g) {
  assert(g != NULL && GraphIsDigraph(g) == 1);

  // Create and initialize the struct

  GraphTopoSort* topoSort = _create(g);

  // Build the topological sorting

  // TO BE COMPLETED
  Graph* copy = GraphCopy(g);   // copia do grafo
  
  unsigned int numVertices = topoSort->numVertices;
  int count=0;
  int* marked = topoSort->marked;
  ATRIB+=4;    // linha 90,92,93,94
 
  for (unsigned int i = 0; i < topoSort->numVertices; i++) {
    COMP +=1;  // for
    ATRIB +=1;  // for
    topoSort->marked[i] = 0;
    ATRIB += 1;  // linha 97
  }

  while ((unsigned int)count != (numVertices)) {   // count conta o index do array resultado, enquanto não for igual ao numero de vertices vai executar
    int found = 0;
    COMP += 1;  // while
    ATRIB += 1; // linha 105
    for (unsigned int i=0; i<(numVertices); i++) {  // percorremos o grafo

      COMP += 1; //for
      ATRIB += 1; // for
      if (GraphGetVertexInDegree(copy,i) == 0 && marked[i]==0) {   // se o vertice tiver inDegree=0 é porque não tem incoming edges
        // e se tiver marked[i]=0 significa que no array marked ainda não guardamos este valor no resultado
        COMP += 2;  // if linha 112
        
        topoSort->vertexSequence[count] = i;   // guardamos o vértice no array resultado
        marked[i] = 1;  // marcamos o vertice como já guardado no resultado
        count++;  // +1 no count para o próximo vertice com inDegree=0 ocupar a posição count no array

        unsigned int* adjacents = GraphGetAdjacentsTo(copy, i); 
        ATRIB += 4;
        for (unsigned int j=1; j<=adjacents[0]; j++) {   // percorremos os vertices
          GraphRemoveEdge(copy,i,adjacents[j]);   // apagamos as arestas para o vertice
          COMP +=1;  
          ATRIB += 1;
        }
        free(adjacents);
        found = 1;
        ATRIB += 1;
      } 
    }
    if (!found) {    // se nenhum vértice tiver inDegree=0, quebramos o while para não entrar em loop
      COMP += 1;
      break;
    }
  }
  GraphDestroy(&copy);
  topoSort->validResult = (count == (int)numVertices) ? 1 : 0;    // verificar se o resultado é valido
  ATRIB+=1;
  COMP += 1;
  return topoSort;
}

//
// Computing the topological sorting, if any, using the 2nd algorithm
// Check if a valid sorting was computed and set the isValid field
// For instance, by checking if the number of elements in the vertexSequence is
// the number of graph vertices
//
GraphTopoSort* GraphTopoSortComputeV2(Graph* g) {
  assert(g != NULL && GraphIsDigraph(g) == 1);

  // Create and initialize the struct

  GraphTopoSort* topoSort = _create(g);

  // Build the topological sorting

  // TO BE COMPLETED
  
  unsigned int numVertices = topoSort->numVertices;                           // Guardar o número de vértices
  unsigned int count=0;                                                       // Criar numa variavel auxiliar iniciada a 0
  ATRIB += 3;
  for (unsigned int i = 0; i < numVertices; i++) {                            // Percorrer todos os vértices
    topoSort->numIncomingEdges[i] = GraphGetVertexInDegree(g, i);             // Guardar num array o indegree de cada vértice
    topoSort->marked[i]=0;                                                    // Iniciar todos os vértices como não marcados(0)
    ATRIB += 3;
    COMP +=1;
  }

  while (count != (numVertices)) {
    COMP+=1;
    int found = 0;
    ATRIB += 1;
    for (unsigned int i = 0; i < numVertices; i++) {
      COMP+=1;
      if (topoSort->numIncomingEdges[i] == 0 && topoSort->marked[i]==0){      // Se indegree igual a 0 e não marcado
        topoSort->vertexSequence[count] = i;                                  // Guardar na sequencia
        count++;                                                              // incrementar variavel auxiliar
        topoSort->marked[i] = 1;                                              // Atualizar como marcado (1)
        unsigned int* adjacents = GraphGetAdjacentsTo(g, i);                  // Pegar nos vértices adjacentes ao selecionado
        ATRIB +=4;
        COMP +=2;
        for (unsigned int j = 1; j<= adjacents[0]; j++) {
          topoSort->numIncomingEdges[adjacents[j]]--;                         // Reduzir um no indegree de todos os vértices que são adjacentes
          ATRIB +=1;
          COMP +=1;
        }
        found=1;
        ATRIB += 1;
        free(adjacents);
      }
    }
    if (!found) {                                                             // se nenhum vértice tiver inDegree=0, quebramos o while para não entrar em loop
      COMP += 1;
      break;
    }
  }
  topoSort->validResult = (count == numVertices) ? 1 : 0;                     // verificar se o resultado é valido                                          // Resultado é válido
  COMP += 1;
  ATRIB+=1;                                                           
  return topoSort;                                                            // Retorna o topoSort
}

//
// Computing the topological sorting, if any, using the 3rd algorithm
// Check if a valid sorting was computed and set the isValid field
// For instance, by checking if the number of elements in the vertexSequence is
// the number of graph vertices
//
GraphTopoSort* GraphTopoSortComputeV3(Graph* g) {
  assert(g != NULL && GraphIsDigraph(g) == 1);

  // Create and initialize the struct

  GraphTopoSort* topoSort = _create(g);

  // Build the topological sorting

  // TO BE COMPLETED
  unsigned int numVertices = topoSort->numVertices;    // guardamos numa variavel o número de vertices do grafo
  Queue* fila = QueueCreate(numVertices);     // criamos uma Queue 
  ATRIB += 3;

  for (unsigned int i = 0; i < topoSort->numVertices; i++) {  // inicializar o array marked
    topoSort->marked[i] = 0;
    COMP += 1;
    ATRIB += 2;
  }

  for (unsigned int i = 0; i < numVertices; i++) {   // percorremos os vértices
    topoSort->numIncomingEdges[i] = GraphGetVertexInDegree(g, i);   // inserimos no array o InDegree de cada vértice
    COMP+=1;
    ATRIB+=2;
    if (GraphGetVertexInDegree(g, i) == 0) {   // se tiver inDegree=0 
      COMP += 1;
      QueueEnqueue(fila,i);   // inserimos na fila
    }
  }

  int count=0;   // index do array final
  ATRIB += 1;
  while(QueueIsEmpty(fila) == 0) {    // enquanto a fila não for vazia
    COMP += 1;
    int v = QueueDequeue(fila);    // Retiramos o próximo vertice da fila
    topoSort->vertexSequence[count] = v;   // inserimos o vertice retirado no array resultado
    count++;   // incrementamos count, para a próxima iteração 
    ATRIB += 3;

    unsigned int* adjacents = GraphGetAdjacentsTo(g, v);  // guardamos o array dos vértices adjacentes
    ATRIB+=1;
    for (unsigned int j = 1; j<= adjacents[0]; j++) {   // percorremos o array
      topoSort->numIncomingEdges[adjacents[j]]--;    // decrementamos no array o número de arestas de cada vértice
      COMP+=1;
      ATRIB+=1;
      if (topoSort->numIncomingEdges[adjacents[j]] == 0) {   // se o número de arestas do vértice for 0
        COMP += 1;
        QueueEnqueue(fila,adjacents[j]);   // inserimos na fila
      }
    }
    free(adjacents);

  }
  topoSort->validResult = (count == (int)numVertices) ? 1 : 0;    // verificar se o resultado é valido
  ATRIB+=1;
  COMP += 1;
  QueueDestroy(&fila);
  return topoSort;
}

void GraphTopoSortDestroy(GraphTopoSort** p) {
  assert(*p != NULL);

  GraphTopoSort* aux = *p;

  free(aux->marked);
  free(aux->numIncomingEdges);
  free(aux->vertexSequence);

  free(*p);
  *p = NULL;
}

//
// A valid sorting was computed?
//
int GraphTopoSortIsValid(const GraphTopoSort* p) { return p->validResult; }

//
// Getting an array containing the topological sequence of vertex indices
// Or NULL, if no sequence could be computed
// MEMORY IS ALLOCATED FOR THE RESULTING ARRAY
//
unsigned int* GraphTopoSortGetSequence(const GraphTopoSort* p) {
  assert(p != NULL);
  // TO BE COMPLETED
  
  if (p->validResult == 0) {         // Verificar se o resultado é valido
    return NULL;
  }

  unsigned int* result = (unsigned int*)malloc(p->numVertices * sizeof(unsigned int)); //Alocar espaço para o array de resultado
  if (result == NULL) {       //Alocação falhou
    return NULL;
  }

  for (unsigned int i = 0; i < p->numVertices; ++i) {
    result[i] = p->vertexSequence[i];       //Copiar o vertexsequence para o novo array
  }

  return result;   //retornar o array de resultado
}

// DISPLAYING on the console

//
// The toplogical sequence of vertex indices, if it could be computed
//
void GraphTopoSortDisplaySequence(const GraphTopoSort* p) {
  assert(p != NULL);

  if (p->validResult == 0) {
    printf(" *** The topological sorting could not be computed!! *** \n");
    return;
  }

  printf("Topological Sorting - Vertex indices:\n");
  for (unsigned int i = 0; i < GraphGetNumVertices(p->graph); i++) {
    printf("%d ", p->vertexSequence[i]);
  }
  printf("\n");
}

//
// The toplogical sequence of vertex indices, if it could be computed
// Followed by the digraph displayed using the adjecency lists
// Adjacency lists are presented in topologic sorted order
//
void GraphTopoSortDisplay(const GraphTopoSort* p) {
  assert(p != NULL);

  // The topological order
  GraphTopoSortDisplaySequence(p);

  if (p->validResult == 0) {
    return;
  }

  // The Digraph
  for (unsigned int i = 0; i < GraphGetNumVertices(p->graph); i++) {
    GraphListAdjacents(p->graph, p->vertexSequence[i]);
  }
  printf("\n");
}
