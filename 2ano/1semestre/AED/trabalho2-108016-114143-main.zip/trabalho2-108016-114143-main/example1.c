//
// Algoritmos e Estruturas de Dados --- 2023/2024
//
// Joaquim Madeira, Joao Manuel Rodrigues - June 2021, Nov 2023
//
// Graph EXAMPLE : Creating and displaying graphs
//

#include "Graph.h"

int main(void) {
  // What kind of graph is g01?
  Graph* g01 = GraphCreate(6, 0, 0);
  GraphAddEdge(g01, 1, 2);
  GraphAddEdge(g01, 1, 4);
  GraphAddEdge(g01, 3, 4);
  printf("The first graph:\n");
  GraphDisplay(g01);
  for (int i = 0; i < 6; i++) {
    GraphListAdjacents(g01, i);
  }
  printf("Remove edge (1,2)\n");
  GraphDisplay(g01);
  for (int i = 0; i < 6; i++) {
    GraphListAdjacents(g01, i);
  }

  Graph* dig01 = GraphCreate(6, 1, 0);
  GraphAddEdge(dig01, 1, 2);
  GraphAddEdge(dig01, 1, 4);
  GraphAddEdge(dig01, 3, 4);
  printf("The second graph:\n");
  GraphDisplay(dig01);
  printf("Remove edge (1,2)\n");
  GraphRemoveEdge(dig01,1,2);
  GraphDisplay(dig01);

  Graph* g03 = GraphCreate(6, 0, 1);
  GraphAddWeightedEdge(g03, 1, 2, 3);
  GraphAddWeightedEdge(g03, 1, 4, 5);
  GraphAddWeightedEdge(g03, 3, 4, 10);
  printf("The third graph:\n");
  GraphDisplay(g03);
  printf("Remove edge (1,2)\n");
  GraphRemoveEdge(g03,1,2);      
  GraphDisplay(g03);
  
  /////////////////////////////////////////////////////////////////
  printf("-------------------------\n");
  printf("---DIGRAFO-SEM PESO---\n");
  /////////   DIGRAFO-SEM PESO  
  Graph* gt = GraphCreate(7, 1, 0);

  GraphAddEdge(gt, 0, 1);
  GraphAddEdge(gt, 0, 2);
  GraphAddEdge(gt, 0, 3);
  GraphAddEdge(gt, 1, 3);
  GraphAddEdge(gt, 1, 4);
  GraphAddEdge(gt, 2, 5);
  GraphAddEdge(gt, 3, 5);
  GraphAddEdge(gt, 3, 6);
  GraphAddEdge(gt, 4, 3);
  GraphAddEdge(gt, 4, 6);
  GraphAddEdge(gt, 6, 5);

  GraphDisplay(gt);

  printf("Remove (0,1)");
  GraphRemoveEdge(gt,0,1);
  GraphDisplay(gt);

  printf("-------------------------\n");
  printf("---GRAFO NÃO ORIENTADO-SEM PESO---\n");
  ///// GRAFO NÃO ORIENTADO-SEM PESO
  Graph* gn = GraphCreate(4, 0, 0);
  GraphAddEdge(gn,0,1);
  GraphAddEdge(gn,1,3);
  GraphAddEdge(gn,3,0);
  GraphAddEdge(gn,1,2);

  GraphDisplay(gn);

  printf("Remove (1,2)\n");
  GraphRemoveEdge(gn,1,2);
  GraphDisplay(gn); 
  
  printf("-------------------------\n");
  printf("---GRAFO NÃO ORIENTADO COM PESO---\n");
  ///// GRAFO NÃO ORIENTADO COM PESO 
  Graph* gy = GraphCreate(6, 0, 1);
  GraphAddWeightedEdge(gy, 1, 2, 3);
  GraphAddWeightedEdge(gy, 1, 4, 5);
  GraphAddWeightedEdge(gy, 3, 4, 10);

  GraphDisplay(gy);

  printf("Remove (1,2)\n");
  GraphRemoveEdge(gy,1,2);
  GraphDisplay(gy);
  
  printf("-------------------------\n");
  printf("---GRAFO ORIENTADO COM PESO---\n");
  ///// GRAFO ORIENTADO COM PESO 
  Graph* gj = GraphCreate(4,1,1);
  GraphAddWeightedEdge(gj,1,2,3);
  GraphAddWeightedEdge(gj,0,2,4);
  GraphAddWeightedEdge(gj,2,3,1);
  GraphAddWeightedEdge(gj,1,3,5);

  GraphDisplay(gj);
  printf("Remove (1,2)\n");
  GraphRemoveEdge(gj,1,2);
  GraphDisplay(gj);  

  /////////////////////////////////////////////////////////////////
  GraphDestroy(&g01);
  GraphDestroy(&dig01);
  GraphDestroy(&g03);
  GraphDestroy(&gt);
  GraphDestroy(&gn);
  GraphDestroy(&gy);
  GraphDestroy(&gj);

  return 0;
}
