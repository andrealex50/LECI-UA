//
// Algoritmos e Estruturas de Dados --- 2023/2024
//
// Joaquim Madeira, Joao Manuel Rodrigues - June 2021, Nov 2023
//
// Graph - Using a list of adjacency lists representation
//

#include "Graph.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "SortedList.h"
#include "instrumentation.h"

struct _Vertex {
  unsigned int id;
  unsigned int inDegree;
  unsigned int outDegree;
  List* edgesList;
};

struct _Edge {
  unsigned int adjVertex;
  double weight;
};

struct _GraphHeader {
  int isDigraph;
  int isComplete;
  int isWeighted;
  unsigned int numVertices;
  unsigned int numEdges;
  List* verticesList;
};

// The comparator for the VERTICES LIST

int graphVerticesComparator(const void* p1, const void* p2) {
  unsigned int v1 = ((struct _Vertex*)p1)->id;
  unsigned int v2 = ((struct _Vertex*)p2)->id;
  int d = v1 - v2;
  return (d > 0) - (d < 0);
}

// The comparator for the EDGES LISTS

int graphEdgesComparator(const void* p1, const void* p2) {
  unsigned int v1 = ((struct _Edge*)p1)->adjVertex;
  unsigned int v2 = ((struct _Edge*)p2)->adjVertex;
  int d = v1 - v2;
  return (d > 0) - (d < 0);
}

Graph* GraphCreate(unsigned int numVertices, int isDigraph, int isWeighted) {
  Graph* g = (Graph*)malloc(sizeof(struct _GraphHeader));
  if (g == NULL) abort();

  g->isDigraph = isDigraph;
  g->isComplete = 0;
  g->isWeighted = isWeighted;

  g->numVertices = numVertices;
  g->numEdges = 0;

  g->verticesList = ListCreate(graphVerticesComparator);

  for (unsigned int i = 0; i < numVertices; i++) {
    struct _Vertex* v = (struct _Vertex*)malloc(sizeof(struct _Vertex));
    if (v == NULL) abort();

    v->id = i;
    v->inDegree = 0;
    v->outDegree = 0;

    v->edgesList = ListCreate(graphEdgesComparator);

    ListInsert(g->verticesList, v);
  }

  assert(g->numVertices == ListGetSize(g->verticesList));

  return g;
}

Graph* GraphCreateComplete(unsigned int numVertices, int isDigraph) {
  Graph* g = GraphCreate(numVertices, isDigraph, 0);

  g->isComplete = 1;

  List* vertices = g->verticesList;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    struct _Vertex* v = ListGetCurrentItem(vertices);
    List* edges = v->edgesList;
    for (unsigned int j = 0; j < g->numVertices; j++) {
      if (i == j) {
        continue;
      }
      struct _Edge* new = (struct _Edge*)malloc(sizeof(struct _Edge));
      if (new == NULL) abort();
      new->adjVertex = j;
      new->weight = 1;

      ListInsert(edges, new);
    }
    if (g->isDigraph) {
      v->inDegree = g->numVertices - 1;
      v->outDegree = g->numVertices - 1;
    } else {
      v->outDegree = g->numVertices - 1;
    }
  }
  if (g->isDigraph) {
    g->numEdges = numVertices * (numVertices - 1);
  } else {
    g->numEdges = numVertices * (numVertices - 1) / 2;
  }

  return g;
}

void GraphDestroy(Graph** p) {
  assert(*p != NULL);
  Graph* g = *p;

  List* vertices = g->verticesList;
  if (ListIsEmpty(vertices) == 0) {
    ListMoveToHead(vertices);
    unsigned int i = 0;
    for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
      struct _Vertex* v = ListGetCurrentItem(vertices);

      List* edges = v->edgesList;
      if (ListIsEmpty(edges) == 0) {
        unsigned int i = 0;
        ListMoveToHead(edges);
        for (; i < ListGetSize(edges); ListMoveToNext(edges), i++) {
          struct _Edge* e = ListGetCurrentItem(edges);
          free(e);
        }
      }
      ListDestroy(&(v->edgesList));
      free(v);
    }
  }

  ListDestroy(&(g->verticesList));
  free(g);

  *p = NULL;
}

Graph* GraphCopy(const Graph* g) {
  assert(g != NULL);

  // TO BE COMPLETED !! 
  Graph* newg = NULL;
  if (g->isComplete == 0) {  // se for um grafo incompleto
    newg = GraphCreate(g->numVertices,g->isDigraph,g->isWeighted); 
  } else {    // se for um grafo completo
    newg = GraphCreateComplete(g->numVertices,g->isDigraph);
  }

  List* vertices = g->verticesList;       // Lista de vertices da g
  List* newvertices = newg->verticesList;  // Lista de vertices da newg

  if (ListIsEmpty(vertices) == 0) {    // Verificamos se tem vertices
    ListMoveToHead(vertices);   // começamos a iterar da cabeça da lista vertices
    ListMoveToHead(newvertices);   // começamos a iterar da cabeça da lista newvertices

    unsigned int i = 0;
    for (; i < g->numVertices; ListMoveToNext(newvertices), ListMoveToNext(vertices), i++) {   // Percorremos a lista de vertices da g
        struct _Vertex* v = ListGetCurrentItem(vertices);  // Pegamos no vertice 
        struct _Vertex* newv = ListGetCurrentItem(newvertices);  // Pegamos no novo vertice
        newv->id = v->id;   // substituimos o valor do id
        newv->inDegree = v->inDegree;   // copiamos o valor do inDegree
        newv->outDegree = v->outDegree;  // copiamos o valor do outDegree

        List* edges = v->edgesList;   // guardamos em edges a lista das arestas do vertice v
        List* newedges = newv->edgesList;  // e o mesmo para o newv
        
        if (ListIsEmpty(edges) == 0) {  // verificamos que a lista não está vazia
          ListMoveToHead(edges);  // começamos a iterar do topo
          ListMoveToHead(newedges);   // começamos a iterar do topo
          unsigned int j = 0;
          for (; j < ListGetSize(edges); ListMoveToNext(edges),ListMoveToNext(newedges), j++) {   // Iteramos a lista de arestas
            struct _Edge* e = ListGetCurrentItem(edges);  // Pegamos na aresta da lista edges
            struct _Edge* newe = (struct _Edge*)malloc(sizeof(struct _Edge));

            newe->adjVertex = e->adjVertex;   // substituimos o valor do adjVertex
            if (g->isWeighted == 1) {     // Se tiver peso associado
              newe->weight = e->weight;    // substituimos o valor da weight
            }
            ListInsert(newedges, newe);
          }
        }
    }
  }
  assert( GraphCheckInvariants(g) );
  return newg;
}

Graph* GraphFromFile(FILE* f) {
  assert(f != NULL);

  // TO BE COMPLETED !! 
  char* filecontent = malloc(1000);     // Reservamos na memória 1000 espaços para caracteres
  int line = 0;   // line vai contar a linha em que estamos
  int numvertices, isweighted, isdigraph, numedges;   
  Graph* g = NULL;   

  while (fgets(filecontent, 1000, f)) {    // percorremos o ficheiro
    if (line == 0) {     // se a linha for 0 
      isdigraph = atoi(filecontent);   // converte para inteiro o conteudo da linha e guarda na variavel isdigraph
    } else if (line == 1) {   // se a linha for 1
      isweighted = atoi(filecontent);  // converte para inteiro o conteudo da linha e guarda na variavel isweighted
    } else if (line == 2) {   // se a linha for 2
      numvertices = atoi(filecontent); // converte para inteiro o conteudo da linha e guarda na variavel numvertices
    } else if (line == 3) {   // se a linha for 3
      numedges = atoi(filecontent);   // converte para inteiro o conteudo da linha e guarda na variavel numedges
      g = GraphCreate(numvertices, isdigraph, isweighted);   // a linha 3 é a ultima linha com informações para criar o 
                                                  // array então podemos criar já, salvaguardando já que não vai ser alterado nas proximas iterações
      g->numEdges = numedges;  // define o valor do numero de arestas
    } else {     // para as outras linhas e resto do ficheiro                                          
      int inicial, final, weight;
      if (g->isWeighted) {
        sscanf(filecontent, "%d %d %d", &inicial, &final, &weight);   // guardamos nas variaveis o valores
      } else {
        sscanf(filecontent, "%d %d", &inicial, &final);
      } 
      int intWeight = (int)(weight * 100);   // convertemos para inteiros, tal como avisado

      if (inicial == final) {   // no caso de ser lacete
        continue;   // passa para a proxima iteração
      }

      if (g != NULL) {   // certificamos que o grafo foi criado
        if (g->isWeighted) {   // se o grafo tiver peso nas arestas
          GraphAddWeightedEdge(g, inicial, final, intWeight);   // adicionamos aresta com peso
        } else {
          GraphAddEdge(g, inicial, final);  // adicionamos aresta
        }
      }
    }
    line++;   
  }
  free(filecontent);   // libertamos o espaço de memória usado
  return g;
}


// Graph

int GraphIsDigraph(const Graph* g) { return g->isDigraph; }

int GraphIsComplete(const Graph* g) { return g->isComplete; }

int GraphIsWeighted(const Graph* g) { return g->isWeighted; }

unsigned int GraphGetNumVertices(const Graph* g) { return g->numVertices; }

unsigned int GraphGetNumEdges(const Graph* g) { return g->numEdges; }

//
// For a graph
//
double GraphGetAverageDegree(const Graph* g) {
  assert(g->isDigraph == 0);
  return 2.0 * (double)g->numEdges / (double)g->numVertices;
}

static unsigned int _GetMaxDegree(const Graph* g) {
  List* vertices = g->verticesList;
  if (ListIsEmpty(vertices)) return 0;

  unsigned int maxDegree = 0;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    struct _Vertex* v = ListGetCurrentItem(vertices);
    if (v->outDegree > maxDegree) {
      maxDegree = v->outDegree;
    }
  }
  return maxDegree;
}

//
// For a graph
//
unsigned int GraphGetMaxDegree(const Graph* g) {
  assert(g->isDigraph == 0);
  return _GetMaxDegree(g);
}

//
// For a digraph
//
unsigned int GraphGetMaxOutDegree(const Graph* g) {
  assert(g->isDigraph == 1);
  return _GetMaxDegree(g);
}

// Vertices

//
// returns an array of size (outDegree + 1)
// element 0, stores the number of adjacent vertices
// and is followed by indices of the adjacent vertices
//
unsigned int* GraphGetAdjacentsTo(const Graph* g, unsigned int v) {
  assert(v < g->numVertices);
  // Node in the list of vertices
  List* vertices = g->verticesList;
  ListMove(vertices, v);
  struct _Vertex* vPointer = ListGetCurrentItem(vertices);
  unsigned int numAdjVertices = vPointer->outDegree;

  unsigned int* adjacent =
      (unsigned int*)calloc(1 + numAdjVertices, sizeof(unsigned int));

  if (numAdjVertices > 0) {
    adjacent[0] = numAdjVertices;
    List* adjList = vPointer->edgesList;
    ListMoveToHead(adjList);
    for (unsigned int i = 0; i < numAdjVertices; ListMoveToNext(adjList), i++) {
      struct _Edge* ePointer = ListGetCurrentItem(adjList);
      adjacent[i + 1] = ePointer->adjVertex;
    }
  }

  return adjacent;
}

//
// returns an array of size (outDegree + 1)
// element 0, stores the number of adjacent vertices
// and is followed by the distances to the adjacent vertices
//
double* GraphGetDistancesToAdjacents(const Graph* g, unsigned int v) {
  assert(v < g->numVertices);

  // Node in the list of vertices
  List* vertices = g->verticesList;
  ListMove(vertices, v);
  struct _Vertex* vPointer = ListGetCurrentItem(vertices);
  unsigned int numAdjVertices = vPointer->outDegree;

  double* distance = (double*)calloc(1 + numAdjVertices, sizeof(double));

  if (numAdjVertices > 0) {
    distance[0] = numAdjVertices;
    List* adjList = vPointer->edgesList;
    ListMoveToHead(adjList);
    for (unsigned int i = 0; i < numAdjVertices; ListMoveToNext(adjList), i++) {
      struct _Edge* ePointer = ListGetCurrentItem(adjList);
      distance[i + 1] = ePointer->weight;
    }
  }

  return distance;
}

//
// For a graph
//
unsigned int GraphGetVertexDegree(Graph* g, unsigned int v) {
  assert(g->isDigraph == 0);
  assert(v < g->numVertices);

  ListMove(g->verticesList, v);
  struct _Vertex* p = ListGetCurrentItem(g->verticesList);

  return p->outDegree;
}

//
// For a digraph
//
unsigned int GraphGetVertexOutDegree(Graph* g, unsigned int v) {
  assert(g->isDigraph == 1);
  assert(v < g->numVertices);

  ListMove(g->verticesList, v);
  struct _Vertex* p = ListGetCurrentItem(g->verticesList);

  return p->outDegree;
}

//
// For a digraph
//
unsigned int GraphGetVertexInDegree(Graph* g, unsigned int v) {
  assert(g->isDigraph == 1);
  assert(v < g->numVertices);

  ListMove(g->verticesList, v);
  struct _Vertex* p = ListGetCurrentItem(g->verticesList);

  return p->inDegree;
}

// Edges

static int _addEdge(Graph* g, unsigned int v, unsigned int w, double weight) {
  struct _Edge* edge = (struct _Edge*)malloc(sizeof(struct _Edge));
  edge->adjVertex = w;
  edge->weight = weight;

  ListMove(g->verticesList, v);
  struct _Vertex* vertex = ListGetCurrentItem(g->verticesList);
  int result = ListInsert(vertex->edgesList, edge);

  if (result == -1) {
    free(edge);
    return 0;
  } else {
    g->numEdges++;
    vertex->outDegree++;

    ListMove(g->verticesList, w);
    struct _Vertex* destVertex = ListGetCurrentItem(g->verticesList);
    destVertex->inDegree++;
  }

  if (g->isDigraph == 0) {
    // Bidirectional edge
    struct _Edge* edge = (struct _Edge*)malloc(sizeof(struct _Edge));
    edge->adjVertex = v;
    edge->weight = weight;

    ListMove(g->verticesList, w);
    struct _Vertex* vertex = ListGetCurrentItem(g->verticesList);
    result = ListInsert(vertex->edgesList, edge);

    if (result == -1) {
      return 0;
    } else {
      // g->numEdges++; // Do not count the same edge twice on a undirected
      // graph !!
      vertex->outDegree++;
    }
  }

  return 1;
}

int GraphAddEdge(Graph* g, unsigned int v, unsigned int w) {
  assert(g->isWeighted == 0);
  assert(v != w);
  assert(v < g->numVertices);
  assert(w < g->numVertices);

  return _addEdge(g, v, w, 1.0);
}

int GraphAddWeightedEdge(Graph* g, unsigned int v, unsigned int w,
                         double weight) {
  assert(g->isWeighted == 1);
  assert(v != w);
  assert(v < g->numVertices);
  assert(w < g->numVertices);

  return _addEdge(g, v, w, weight);
}

int GraphRemoveEdge(Graph* g, unsigned int v, unsigned int w) {
  assert(g != NULL);

  // TO BE COMPLETED !!
  ListMove(g->verticesList, v);                                         // Procurar o vértive v na lista de vértices
  struct _Vertex* vertex = ListGetCurrentItem(g->verticesList);        
  if (vertex == NULL) {
    return 0;                                                           // Não foi possível encontrar o vértice na lista
  }

  ListMoveToHead(vertex->edgesList);                                    // Ir para o inicio da lista de arestas do vértice v
  struct _Edge* rem_edge = ListGetCurrentItem(vertex->edgesList);       // Selecionar a primeira aresta
  while (rem_edge != NULL && rem_edge->adjVertex != w) {                // Enquanto não for uma aresta com o vertice adjacente w
      ListMoveToNext(vertex->edgesList);                                // Avançar para a proxima aresta
      rem_edge = ListGetCurrentItem(vertex->edgesList);                 // Selecionar aresta
  }

  if (rem_edge == NULL || rem_edge->adjVertex != w) {                   // Caso não ache nenhuma aresta com os requisitos
      return 0;                                                         // retorna 0
  }

  ListRemoveCurrent(vertex->edgesList);                                 // Remover a aresta da lista
  free(rem_edge);                                                       // Libertar a memória que era ocupada pela mesma

  vertex->outDegree--;                                                  // -1 no outDegree pois tem menos 1 aresta
  g->numEdges--;                                                        // Decrementar o número de arestas do grafo

  ListMove(g->verticesList, w);
  struct _Vertex* destVertex = ListGetCurrentItem(g->verticesList);     // Procurar o segundo vértice na lista de vértices
  destVertex->inDegree--;                                               // -1 no inDegree pois tem menos 1 aresta

  if (g->isDigraph == 0) {                                              // Grafos não direcionados
    ListMove(g->verticesList, w);                                       // Movemos para o index do w
    struct _Vertex* destVertex = ListGetCurrentItem(g->verticesList);   // Guardamos o vertice destino
    if (destVertex == NULL) {                                           // Se ocorreu algum erro
      return 0;
    }

    ListMoveToHead(destVertex->edgesList);                              // Movemos para a cabeça da lista das arestas do vertice
    struct _Edge* rev_edge = ListGetCurrentItem(destVertex->edgesList); // guardamos a aresta
    while (rev_edge != NULL && rev_edge->adjVertex != v) {              // Encontra a aresta com o vértice de destino igual a v
      ListMoveToNext(destVertex->edgesList);                            // Move para a próxima aresta na lista 
      rev_edge = ListGetCurrentItem(destVertex->edgesList);             // obtem a aresta atual
    }

    if (rev_edge != NULL && rev_edge->adjVertex == v) {                 // Se a aresta adjacente for igual a v
      ListRemoveCurrent(destVertex->edgesList);                         // Removemos esse vertice da lista de arestas
      free(rev_edge);                                                   // Libertamos o espaço de memória

      destVertex->inDegree--;                                           // -1 no inDegree pois tem menos 1 aresta
    }
  }
  assert( GraphCheckInvariants(g) );
  return 1;                                                             // Aresta removida com sucesso
}

// CHECKING

int GraphCheckInvariants(const Graph* g) {
  assert(g != NULL);
  // TO BE COMPLETED !!
  if (g->numVertices==0){return 0;}                                     // O grafo deve ter pelo menos um vértice

  for (unsigned int i = 0; i < g->numVertices; ++i) {
    ListMove(g->verticesList, i);
    struct _Vertex* vertex = ListGetCurrentItem(g->verticesList);
    if (g->isDigraph && vertex->outDegree > g->numVertices) {return 0;} // Não podemos ter um out-degree maior que o número de vértices. 

    if (g->isDigraph && vertex->inDegree > g->numVertices) {return 0;}  // Não podemos ter um in-degree maior que o número de vértices. 

    if (!g->isDigraph && (vertex->inDegree + vertex->outDegree) > g->numVertices) {return 0;}  // Não podemos ter um degree maior que o número de vértices. 
  }

  return 1;                                                             // Retorna verdadeiro caso passe nas condições
}

// DISPLAYING on the console

void GraphDisplay(const Graph* g) {
  printf("---\n");
  if (g->isWeighted) {
    printf("Weighted ");
  }
  if (g->isComplete) {
    printf("COMPLETE ");
  }
  if (g->isDigraph) {
    printf("Digraph\n");
    printf("Max Out-Degree = %d\n", GraphGetMaxOutDegree(g));
  } else {
    printf("Graph\n");
    printf("Max Degree = %d\n", GraphGetMaxDegree(g));
  }
  printf("Vertices = %2d | Edges = %2d\n", g->numVertices, g->numEdges);

  List* vertices = g->verticesList;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    printf("%2d ->", i);
    struct _Vertex* v = ListGetCurrentItem(vertices);
    if (ListIsEmpty(v->edgesList)) {
      printf("\n");
    } else {
      List* edges = v->edgesList;
      unsigned int i = 0;
      ListMoveToHead(edges);
      for (; i < ListGetSize(edges); ListMoveToNext(edges), i++) {
        struct _Edge* e = ListGetCurrentItem(edges);
        if (g->isWeighted) {
          printf("   %2d(%4.2f)", e->adjVertex, e->weight);
        } else {
          printf("   %2d", e->adjVertex);
        }
      }
      printf("\n");
    }
  }
  printf("---\n");
}

void GraphListAdjacents(const Graph* g, unsigned int v) {
  printf("---\n");

  unsigned int* array = GraphGetAdjacentsTo(g, v);

  printf("Vertex %d has %d adjacent vertices -> ", v, array[0]);

  for (unsigned int i = 1; i <= array[0]; i++) {
    printf("%d ", array[i]);
  }

  printf("\n");

  free(array);

  printf("---\n");
}
