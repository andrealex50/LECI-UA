function showMore() {
    if (document.getElementById('moreInfo').style.display === 'none') {
        document.getElementById('moreInfo').style.display = 'block';
        document.getElementById('show-more').textContent = 'Show Less';
    }
    else {
        document.getElementById('moreInfo').style.display = 'none';
        document.getElementById('show-more').textContent = 'Show More';
    }
}

document.getElementById('newsletterForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Thank you for subscribing to our newsletter!');
});

var games = ['Fúria Metálica: Renascimento Técnico', 'Risco Real: Cartas em Chamas']; // Replace with actual game names
var gameList = document.getElementById('gameList');
games.forEach(function(game) {
    var gameElement = document.createElement('p');
    gameElement.textContent = game;
    gameList.appendChild(gameElement);
});