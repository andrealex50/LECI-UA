Este ficheiro apresenta algumas informações relativamente aos ficheiros encontrados dentro da pasta.

- amazing.pt-80.conf situa-se na vm da amazing inc em /etc/apache2/sites-available
- amazing.pt-80 (pasta) situa-se na vm da amazing inc em /var/www/html/
