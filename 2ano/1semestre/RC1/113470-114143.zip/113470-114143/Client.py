import socket
import signal
import sys
from datetime import datetime
import threading

def signal_handler(sig, frame):
    print('\nDone!')
    sys.exit(0)

def handle_client_listening():
    try:
        while True:
            response = sock.recv(4096).decode()
            print('\n{}'.format(response))
    except (socket.timeout, socket.error):
        return

signal.signal(signal.SIGINT, signal_handler)
print('Press Ctrl+C to exit...')

##

ip_addr = "127.0.0.1"
tcp_port = 5005
hostname = "RealServer"

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.connect((ip_addr, tcp_port))

while True:
    #Start thread to listen to server all the time
    clientListen = threading.Thread(target=handle_client_listening,daemon=True)
    clientListen.start()

    try:
        message=input("> ")
        if len(message)>1:
            #Realtime when message is send
            dateAsString = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            #Message is sent with name and date
            addr = str(sock.getsockname())
            message = (hostname +"( " + addr + " )" +  " at " + dateAsString + ":\n" + message +"\n").encode()
            sock.send(message)

            #response = sock.recv(4096).decode()
            #print('{}'.format(response))
    except (socket.timeout, socket.error):
        print('Server error. Done!')
        sys.exit(0)

